import matplotlib.pyplot as plt
import numpy as np
from matplotlib import rcParams


config = {
    "font.family":'Times New Roman',  # 设置字体类型
    "font.size":13,
    "mathtext.fontset":'stix',
}
rcParams.update(config)
K = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

d2_1_N = [32.7,71.8,72.4,68.0,73.1,81.5,99.3,105,97.6,107,111,109,120,113,113]
d2_2_N = [44.7,37.6,50.0,53.1,60.3,60.7,62.5,63.8,65.4,68.8,76.7,77.8,77.0,78.7,84.7]
d4_1_N = [41.9,53.4,69.5,61.5,67.7,83.6,86.9,94.8,87.8,99.9,103,102,107,102,103]
d4_2_N = [50.0,52.8,51.0,55.5,63.3,60.0,67.6,68.2,71.6,77.8,87.1,86.6,87.2,87.7,92.8]
var_1_N = [159,47.7,32.3,34.3,32.7,29.6,29.7,32.7,35.6,36.0,34.7,39.1,36.0,37.2,40.0]
var_2_N = [227,48.6,40.6,29.8,31.0,31.5,34.8,34.2,30.8,35.0,41.3,37.7,39.9,37.8,40.2]

d2_1_t = [37.1,36.5,39.3,44.0,42.2,51.5,51.6,60.4,61.2,63.6,57.0,61.3,59.0,72.7,68.9]
d2_2_t = [31.5,37.2,44.1,48.6,50.5,50.1,57.2,58.6,56.0,64.4,69.8,66.3,62.7,77.3,74.1]
d4_1_t = [40.2,44.9,42.9,52.4,47.9,57.4,56.9,64.3,62.4,68.8,63.2,71.4,65.4,72.7,68.2]
d4_2_t = [33.1,31.6,40.0,42.0,44.2,48.4,53.7,53.7,51.7,62.3,62.1,67.9,63.3,68.5,66.0]
var_1_t = [192,74.1,73.8,61.8,61.0,62.7,62.9,63.8,57.2,62.4,58.1,62.6,56.1,64.0,66.8]
var_2_t = [292,50.5,36.6,35.7,31.6,33.3,33.9,39.1,41.8,49.3,43.3,53.4,44.2,57.4,46.4]

d2_1_chi = [39.6,44.0,33.6,40.6,40.1,40.3,42.0,41.2,43.1,43.4,45.7,43.7,44.8,47.6,47.9]
d2_2_chi = [53.6,33.8,36.3,38.1,41.6,41.9,42.6,41.2,42.7,42.7,43.8,43.5,43.8,43.4,46.1]
d4_1_chi = [28.1,25.1,28.2,29.7,31.7,32.1,38.7,35.8,37.2,38.9,40.5,37.7,38.1,41.3,42.5]
d4_2_chi = [73.2,72.6,41.6,52.8,53.9,51.3,55.7,53.1,52.7,56.2,54.2,54.1,55.7,56.0,58.1]
var_1_chi = [86.6,19.9,19.4,17.4,18.7,20.8,19.0,19.0,19.0,20.2,21.6,22.0,23.9,24.2,23.8]
var_2_chi = [210,57.5,29.1,26.5,24.1,21.3,22.8,20.1,20.4,19.9,20.6,19.0,18.7,19.4,19.4]

fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 5))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$K$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(1, 16, 3)))
ax1.plot(K, np.log(d2_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(K, np.log(d2_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.3, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$K$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(1, 16, 3)))
ax2.plot(K, np.log(d2_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(K, np.log(d2_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.3, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$K$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(1, 16, 3)))
ax3.plot(K, np.log(d2_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(K, np.log(d2_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.3, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
plt.savefig(r'.\M_d2_K.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()

#############################################################################


fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 5))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$K$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(1, 16, 3)))
ax1.plot(K, np.log(d4_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(K, np.log(d4_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.3, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$K$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(1, 16, 3)))
ax2.plot(K, np.log(d4_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(K, np.log(d4_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.3, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$K$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(1, 16, 3)))
ax3.plot(K, np.log(d4_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(K, np.log(d4_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.3, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
plt.savefig(r'.\M_d4_K.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()


#############################################################################


fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 5))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$K$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(1, 16, 3)))
ax1.plot(K, np.log(var_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(K, np.log(var_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.3, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$K$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(1, 16, 3)))
ax2.plot(K, np.log(var_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(K, np.log(var_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.3, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$K$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(1, 16, 3)))
ax3.plot(K, np.log(var_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(K, np.log(var_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.3, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
plt.savefig(r'.\M_var_K.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()