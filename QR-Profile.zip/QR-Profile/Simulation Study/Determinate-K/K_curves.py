import matplotlib.pyplot as plt
import numpy as np
from matplotlib import rcParams


config = {
    "font.family":'Times New Roman',  # 设置字体类型
    "font.size":13,
    "mathtext.fontset":'stix'
}
rcParams.update(config)
K = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

b0_1_N = [17.1,20.2,19.6,21.9,27.5,26.4,26.7,27.7,32.4,37.0,40.9,43.3,42.7,39.7,40.0]
b0_2_N = [15.6,17.2,19.1,22.1,22.2,22.5,21.4,25.5,28.1,30.4,33.2,31.9,31.1,31.7,32.4]
b1_1_N = [45.6,45.2,56.9,89.5,100,91.9,86.3,94.5,118,136,144,137,138,140,138]
b1_2_N = [49.9,54.5,57.5,54.0,57.4,60.7,65.1,70.8,72.0,75.1,82.9,80.0,78.7,76.4,83.6]
var_1_N = [196,38.5,27.9,34.6,35.1,33.1,31.5,29.3,33.9,34.8,36.5,37.8,36.2,38.8,38.3]
var_2_N = [197,29.0,20.5,18.4,18.5,17.9,16.9,20.0,22.1,25.4,26.8,26.6,25.6,26.8,28.0]


b0_1_t = [11.0,15.7,15.5,16.2,19.0,17.8,19.2,23.1,24.7,22.5,25.0,25.4,25.2,29.2,28.0]
b0_2_t = [11.1,11.1,13.1,15.0,16.1,16.3,17.5,18.4,21.6,20.6,22.8,23.1,22.6,24.7,25.9]
b1_1_t = [32.1,38.6,36.7,38.7,48.4,47.7,50.4,58.2,57.6,55.8,65.2,68.2,61.2,68.0,65.3]
b1_2_t = [30.4,39.1,55.1,67.7,64.5,60.3,68.1,76.8,95.7,87.3,86.4,82.9,83.8,102,110]
var_1_t = [201,28.4,20.7,27.0,26.2,25.5,26.3,26.1,31.4,29.6,29.5,30.2,28.7,32.4,34.0]
var_2_t = [202,35.6,30.8,24.1,27.4,26.9,31.7,43.1,45.0,43.7,42.2,41.5,44.8,42.1,49.9]

b0_1_chi = [15.2,14.9,13.2,12.7,13.8,14.0,15.2,15.7,15.4,15.3,15.4,15.6,16.2,16.0,16.4]
b0_2_chi = [12.9,11.8,11.0,12.7,13.4,15.5,14.8,16.0,16.4,17.3,17.8,18.9,21.0,20.6,21.2]
b1_1_chi = [51.8,64.6,44.5,46.0,53.2,62.1,57.0,65.5,74.9,79.8,78.7,82.6,84.1,76.3,78.2]
b1_2_chi = [35.4,34.5,30.0,34.2,39.3,44.3,38.1,45.0,41.3,40.8,40.0,40.1,41.7,40.8,41.6]
var_1_chi = [83.9,13.5,10.7,12.0,12.2,12.4,11.7,13.1,13.3,13.6,14.2,14.6,15.7,15.3,15.9]
var_2_chi = [128,29.7,19.0,15.6,15.4,17.6,16.2,15.5,15.3,15.0,14.1,14.0,14.5,13.1,13.9]


fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 5))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$K$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(1, 16, 3)))
ax1.plot(K, np.log(b0_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(K, np.log(b0_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.3, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$K$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(1, 16, 3)))
ax2.plot(K, np.log(b0_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(K, np.log(b0_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.3, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$K$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(1, 16, 3)))
ax3.plot(K, np.log(b0_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(K, np.log(b0_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.3, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
#plt.savefig(r'.\S_b0_K.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()

#############################################################################

fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 5))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$K$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(1, 16, 3)))
ax1.plot(K, np.log(b1_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(K, np.log(b1_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.3, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$K$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(1, 16, 3)))
ax2.plot(K, np.log(b1_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(K, np.log(b1_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.3, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$K$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(1, 16, 3)))
ax3.plot(K, np.log(b1_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(K, np.log(b1_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.3, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
#plt.savefig(r'.\S_b1_K.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()


#############################################################################


fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 5))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$K$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(1, 16, 3)))
ax1.plot(K, np.log(var_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(K, np.log(var_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.3, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$K$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(1, 16, 3)))
ax2.plot(K, np.log(var_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(K, np.log(var_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.3, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$K$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(1, 16, 3)))
ax3.plot(K, np.log(var_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(K, np.log(var_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.3, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
#plt.savefig(r'.\S_var_K.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()