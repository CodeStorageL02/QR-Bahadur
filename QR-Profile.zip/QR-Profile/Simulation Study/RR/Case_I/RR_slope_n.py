import numpy as np
from related_functions import wilcoxon_rank,spacial_sign_R
import time

def sigma_sum(X,Y,beta,a):
    sig = Y - X @ beta - a
    return np.sum(sig ** 2)


# 真实模型参数
eta_t = np.array([3,2]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数
np.random.seed(2) # 25


p = 2
Num = 20
m=1000
Z_matrix = np.zeros((m,p+1))
for t in range(m):

    x = np.random.normal(loc=0,scale=0.5,size=Num)
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x)).T

# 随机误差
    # Sceniro 1
    err = np.random.normal(0, var_t, (Num, 1))  # normal errors

    y_0 = X_0 @ eta_t + err

# IC 状态参数估计

    a_0 = np.mean(y_0)

    b_1 = wilcoxon_rank(x.reshape(-1,1),np.squeeze(y_0))

    sigma_0 = sigma_sum(x.reshape(-1,1),y_0,b_1.reshape(-1,1),a_0)/(Num-p)
    z = np.concatenate([[a_0], np.array(b_1), [sigma_0]])
    Z_matrix[t, :] = z
print(Z_matrix.shape)

med, S = spacial_sign_R(Z_matrix)

print(med)
print(S)


def Rank_eta(limit, file_name,eta_OC, lam=0.1, size=20):
    """

    :param limit: 控制线
    :param ld: EWMA系数
    :param N: 时间窗口宽度
    :param file_name:  保存文件名称
    :param eta_OC:
    :return:  无
    """
    nSimu = 10000  # 循环次数
    nMaxRL = 3000  # ARL_0最大上限

    Limit = limit  # 控制线
    n = size  # 样本个数

    print(eta_OC)

    RL = []
    for i in range(nSimu):
        w = np.zeros(p + 1)

        k = 0
        Rlt = 0
        while (Rlt < Limit and k < nMaxRL):
            k += 1
            x = np.random.normal(loc=0, scale=0.5, size=n)
            l_1 = np.array([1 for i in range(n)])
            X = np.vstack((l_1, x)).T
            err = np.random.normal(0, var_t, (n, 1))
            y = X @ eta_OC + err

            a_c = np.mean(y)

            b_1_c = wilcoxon_rank(x.reshape(-1, 1), np.squeeze(y))

            sigma_c = sigma_sum(x.reshape(-1, 1), y, b_1_c.reshape(-1, 1), a_c) / (n - p)

            z = np.concatenate([[a_c], np.array(b_1_c), [sigma_c]])

            z = (z - med) @ S.T
            z = z / np.linalg.norm(z)
            w = (1 - lam) * w + lam * z

            Rlt = (2 - lam) / lam * (p + 1) * w @ w.T

        RL.append(k)
    ARL = np.mean(RL)
    StdRL = np.std(RL) / np.sqrt(nSimu)
    with open(file_name + '.txt', 'a') as file:
        file.write("shift - %s \n" % (eta_OC - eta_t))
        file.write('ARL:\t{:.4f},\t{:.4f},\t{:.4f},\t{:.4f}\n'.format(ARL, StdRL, Limit, lam))
    print('ARL:', ARL, StdRL, Limit, lam)


if __name__ == '__main__':
    file_name = './ARL/Rank_slope_n111'

    delta_list = [-0.5, -0.4, -0.3, -0.2, -0.1, -0.05, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5]
    size = 20
    lam_d = 0.1
    print(size)
    print(lam_d)
    shift_mat = np.eye(p)
    limit = 10.101 #
    for j in range(p):
        with open(file_name + '.txt', 'a') as file:
            file.write("eta%s n=20 O^{-1} c_ ************************************************ \n"%(j))
        shift_vec = shift_mat[j,:].reshape(-1,1)
        for i in delta_list:
            eta_OC = shift_vec * i + eta_t
            start_time = time.time()
            Rank_eta(limit=limit, file_name=file_name, eta_OC=eta_OC, lam=lam_d, size=size)
            end_time = time.time()
            run_time = end_time - start_time
            with open(file_name + '.txt', 'a') as file:
                file.write("it  cost %s s for func running\n " % (round(run_time, 3)))

