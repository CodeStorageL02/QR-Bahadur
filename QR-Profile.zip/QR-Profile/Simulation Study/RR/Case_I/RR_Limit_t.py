import numpy as np
from related_functions import wilcoxon_rank,spacial_sign_R
import time
from scipy.stats import t

def sigma_sum(X,Y,beta,a):
    sig = Y - X @ beta - a
    return np.sum(sig ** 2)


# 真实模型参数
eta_t = np.array([3,2]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数
np.random.seed(2)
p = 2
Num = 20
m=1000
Z_matrix = np.zeros((m,p+1))

for s in range(m):

    x = np.random.normal(loc=0,scale=0.5,size=Num)
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x)).T

# 随机误差
    #Sceniro 2 -- t-distribution
    err = t.rvs(df=4,size=Num).reshape(-1,1)/np.sqrt(2) #t-distribution

    y_0 = X_0 @ eta_t + err

# IC 状态参数估计

    a_0 = np.mean(y_0)

    b_1 = wilcoxon_rank(x.reshape(-1,1),np.squeeze(y_0))

    sigma_0 = sigma_sum(x.reshape(-1,1),y_0,b_1.reshape(-1,1),a_0)/(Num-p)
    z = np.concatenate([[a_0], np.array(b_1), [sigma_0]])
    Z_matrix[s, :] = z
print(Z_matrix.shape)

med, S = spacial_sign_R(Z_matrix)

print(med)
print(S)

#找控制线
nSimu = 10000 # 循环次数
nMaxRL = 3000 # ARL_0最大上限

def Rank_Limit(limitL,limitR,file_name,lam=0.1,size=20):
    """
       :param limitL: 控制线下线
       :param limitR: 控制线上限
       :param file_name:  保存文件名
       :return: 无
       """
    start_time = time.time()
    LimitL = limitL
    LimitR = limitR
    n = size
    ARL = 220

    while abs(ARL - 200) >= 2 :
        Limit = (LimitL + LimitR) / 2
        RL = []
        for i in range(nSimu):
            w = np.zeros(p + 1)

            k = 0
            Rlt = 0
            while (Rlt < Limit and k < nMaxRL):
                k += 1
                x = np.random.normal(loc=0, scale=0.5, size=n)
                l_1 = np.array([1 for i in range(n)])
                X = np.vstack((l_1, x)).T
                err = t.rvs(df=4,size=n).reshape(-1,1)/np.sqrt(2)
                y = X @ eta_t + err

                a_c = np.mean(y)

                b_1_c = wilcoxon_rank(x.reshape(-1, 1), np.squeeze(y))

                sigma_c = sigma_sum(x.reshape(-1, 1), y, b_1_c.reshape(-1, 1), a_c) / (n - p)

                z = np.concatenate([[a_c], np.array(b_1_c), [sigma_c]])
                z = (z - med) @ S.T
                z = z / np.linalg.norm(z)
                w = (1 - lam) * w + lam * z

                Rlt = (2 - lam) / lam * (p + 1) * w @ w.T

            RL.append(k)
        ARL = np.mean(RL)
        StdRL = np.std(RL)/np.sqrt(nSimu)
        with open(file_name + '.txt', 'a') as file:
            file.write('ARL:\t{:.4f},\t{:.4f},\t{:.4f}\n'.format(ARL, StdRL, Limit))
        print('ARL:', ARL, StdRL, Limit)
        if (ARL < 200):
            LimitL = Limit
        else:
            LimitR = Limit
    end_time = time.time()
    run_time = end_time - start_time
    print("it  cost %s s for func running " % (round(run_time, 3)))

    with open(file_name + '.txt', 'a') as file:
        file.write("it  cost %s s for func running\n " % (round(run_time, 3)))

if __name__ == '__main__':
    file_name = './Limit/Rank_limit_t000'
    size = 20
    lam_d = 0.1
    print(size)
    print(lam_d)
    with open(file_name + '.txt', 'a') as file:
        file.write("n=20 t-student O^{-1} c_ \n")
    Rank_Limit(limitL=8.052,limitR=15.81,file_name=file_name,lam=lam_d,size=size)


