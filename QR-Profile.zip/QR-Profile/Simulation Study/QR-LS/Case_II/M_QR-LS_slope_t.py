import numpy as np
from related_functions import estimate_sq, build_omega,build_R
import time
from IRLS import IRLS
from scipy.stats import t

p = 5
Num = 20000

# 真实模型参数
eta_t = np.array([2,1,-3,-2,4]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数 Multiple
np.random.seed(2)
mean_x = np.zeros(p-1)
cov_x = np.array([[0.5,0.25,0.125,0.0625],[0.25,0.5,0.25,0.125],[0.125,0.25,0.5,0.25],[0.0625,0.125,0.25,0.5]])
print(cov_x)
x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=Num).T
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 2 -- t-distribution
err = t.rvs(df=4,size=Num,random_state=2).reshape(-1,1)/np.sqrt(2) #t-distribution
print(np.mean(err))
print(np.std(err))

y_0 = X_0 @ eta_t + err


# IC 状态参数估计
tau = 0.5
rho = 0.25


# 估计三个分位点的回归系数
beta_tau_0 = IRLS(tau, y_0, X_0)
beta_rho_0 = IRLS(rho, y_0, X_0)
beta_1rho_0 = IRLS(1 - rho,y_0, X_0)

# 估计设计矩阵

D_hat = X_0.T @ X_0 / Num
print(D_hat)

# 估计稀疏函数 s(q)
s_tau = estimate_sq(X_0,y_0, tau)
s_rho = estimate_sq(X_0,y_0, rho)
s_1rho = estimate_sq(X_0,y_0, 1 - rho)
print(s_tau,s_rho,s_1rho)

be_all_0 = np.concatenate([beta_tau_0, beta_rho_0, beta_1rho_0])
print(be_all_0)

# 构建协方差矩阵
Omega = build_omega([tau, rho, 1 - rho], [s_tau, s_rho, s_1rho])

R = build_R(p)
Sigma = R @ np.kron(Omega, np.linalg.inv(D_hat)) @ R.T
S_inv = np.linalg.inv(Sigma)


def QR_T_beta(limit, file_name,eta_OC, lam=0.2, size=20):
    """

    :param limit: 控制线
    :param ld: EWMA系数
    :param N: 时间窗口宽度
    :param file_name:  保存文件名称
    :param eta_OC:
    :return:  无
    """
    nSimu = 10000  # 循环次数
    nMaxRL = 3000  # ARL_0最大上限

    Limit = limit  # 控制线
    n = size  # 样本个数

    print(eta_OC)

    RL = []
    for i in range(nSimu):
        z = np.zeros((2 * p, 1))

        k = 0
        Rlt = 0
        while (Rlt < Limit and k < nMaxRL):
            k += 1
            x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=n).T
            l_1 = np.array([1 for i in range(n)])
            X = np.vstack((l_1, x)).T
            err = t.rvs(df=4,size=n).reshape(-1,1)/np.sqrt(2)

            y = X @ eta_OC + err

            beta_tau = IRLS(tau, y, X)
            beta_rho = IRLS(rho, y, X)
            beta_1rho = IRLS(1 - rho, y, X)
            det = np.concatenate([beta_tau, beta_rho, beta_1rho]) - be_all_0
            v = R @ det
            z = (1 - lam) * z + lam * v

            Rlt = n * np.squeeze(z) @ S_inv @ np.squeeze(z)


        RL.append(k)
    ARL = np.mean(RL)
    StdRL = np.std(RL) / np.sqrt(nSimu)
    with open(file_name + '.txt', 'a') as file:
        file.write("shift - %s \n" % (eta_OC - eta_t))
        file.write('ARL:\t{:.4f},\t{:.4f},\t{:.4f},\t{:.4f}\n'.format(ARL, StdRL, Limit, lam))
    print('ARL:', ARL, StdRL, Limit, lam)


if __name__ == '__main__':
    file_name = './ARL/TQR_slope_t'

    delta_list = [-0.5, -0.4, -0.3, -0.2, -0.1, -0.05, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5]
    size = 20
    lam_d = 0.1
    print(size)
    print(lam_d)
    shift_mat = np.eye(p)
    limit = 2.021
    for j in range(p):
        with open(file_name + '.txt', 'a') as file:
            file.write("t-student beta%s n=20 ************************************************ \n"%(j))
        shift_vec = shift_mat[j,:].reshape(-1,1)
        for i in delta_list:
            eta_OC = shift_vec * i + eta_t
            start_time = time.time()
            QR_T_beta(limit=limit, file_name=file_name, eta_OC=eta_OC, lam=lam_d, size=size)
            end_time = time.time()
            run_time = end_time - start_time
            with open(file_name + '.txt', 'a') as file:
                file.write("it  cost %s s for func running\n " % (round(run_time, 3)))