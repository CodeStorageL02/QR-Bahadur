import numpy as np
from related_functions import estimate_sq, build_omega,build_R
import time
from IRLS import IRLS
from scipy.stats import t

p = 2
Num = 20000

# 真实模型参数
eta_t = np.array([3,2]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数
np.random.seed(2)
x = np.random.normal(loc=0,scale=0.5,size=Num)
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 2 -- t-distribution
err = t.rvs(df=4,size=Num,random_state=9).reshape(-1,1)/np.sqrt(2) #t-distribution
print(np.mean(err))
print(np.std(err))

y_0 = X_0 @ eta_t + err


# IC 状态参数估计
tau = 0.5
rho = 0.25


# 估计三个分位点的回归系数
beta_tau_0 = IRLS(tau, y_0, X_0)
beta_rho_0 = IRLS(rho, y_0, X_0)
beta_1rho_0 = IRLS(1 - rho,y_0, X_0)

# 估计设计矩阵

D_hat = X_0.T @ X_0 / Num
print(D_hat)

# 估计稀疏函数 s(q)
s_tau = estimate_sq(X_0,y_0, tau)
s_rho = estimate_sq(X_0,y_0, rho)
s_1rho = estimate_sq(X_0,y_0, 1 - rho)
print(s_tau,s_rho,s_1rho)

be_all_0 = np.concatenate([beta_tau_0, beta_rho_0, beta_1rho_0])
print(be_all_0.shape)

# 构建协方差矩阵
Omega = build_omega([tau, rho, 1 - rho], [s_tau, s_rho, s_1rho])

R = build_R(p)
Sigma = R @ np.kron(Omega, np.linalg.inv(D_hat)) @ R.T

S_inv = np.linalg.inv(Sigma)

#找控制线
nSimu = 10000 # 循环次数
nMaxRL = 3000 # ARL_0最大上限


def TQR_sigma(limit, file_name,delta, lam=0.1, size=20):
    """

    :param limit: 控制线
    :param ld: EWMA系数
    :param N: 时间窗口宽度
    :param file_name:  保存文件名称
    :return:  无
    """
    nSimu = 10000  # 循环次数
    nMaxRL = 3000  # ARL_0最大上限

    Limit = limit  # 控制线
    n = size  # 样本个数
    print(delta)

    RL = []
    for i in range(nSimu):
        z = np.zeros((2 * p, 1))

        k = 0
        Rlt = 0
        while (Rlt < Limit and k < nMaxRL):
            k += 1
            x = np.random.normal(loc=0, scale=0.5, size=n)
            l_1 = np.array([1 for i in range(n)])
            X = np.vstack((l_1, x)).T
            err = t.rvs(df=4, size=n).reshape(-1, 1) / np.sqrt(2)
            err_OC = (1 + delta) * err

            y = X @ eta_t + err_OC

            beta_tau = IRLS(tau, y, X)
            beta_rho = IRLS(rho, y, X)
            beta_1rho = IRLS(1 - rho, y, X)
            det = np.concatenate([beta_tau, beta_rho, beta_1rho]) - be_all_0
            v = R @ det
            z = (1 - lam) * z + lam * v

            Rlt = n * np.squeeze(z) @ S_inv @ np.squeeze(z)

        RL.append(k)
    ARL = np.mean(RL)
    StdRL = np.std(RL) / np.sqrt(nSimu)
    with open(file_name + '.txt', 'a') as file:
        file.write("shift - %s \n" % (delta))
        file.write('ARL:\t{:.4f},\t{:.4f},\t{:.4f},\t{:.4f}\n'.format(ARL, StdRL, Limit, lam))
    print('ARL:', ARL, StdRL, Limit, lam)


if __name__ == '__main__':
    file_name = './ARL/TQR_variance_t'
    with open(file_name + '.txt', 'a') as file:
        file.write("t-student N=20 *********************************************************************\n")

    #delta_list = [0,0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5] # [0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1]
    delta_list = [-0.5, -0.4, -0.3, -0.2, -0.1, -0.05, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5]
    size = 20
    lam_d = 0.1
    print(size)
    print(lam_d)
    limit = 0.9126
    for i in delta_list:
        start_time = time.time()
        TQR_sigma(limit=limit, file_name=file_name, delta= i, lam=lam_d, size=size)
        end_time = time.time()
        run_time = end_time - start_time
        with open(file_name + '.txt', 'a') as file:
            file.write("it  cost %s s for func running\n " % (round(run_time, 3)))