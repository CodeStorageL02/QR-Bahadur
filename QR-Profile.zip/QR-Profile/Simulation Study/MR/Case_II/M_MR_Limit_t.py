import numpy as np
from scipy.stats import multivariate_normal as M_n
import time
from scipy.stats import t

def sigma_sum(X,Y,beta):
    sig = Y - X @ beta
    return np.sum(sig ** 2)

p = 5
Num = 20000

# 真实模型参数
eta_t = np.array([2,1,-3,-2,4]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数 Multiple
np.random.seed(2)
mean_x = np.zeros(p-1)
cov_x = np.array([[0.5,0.25,0.125,0.0625],[0.25,0.5,0.25,0.125],[0.125,0.25,0.5,0.25],[0.0625,0.125,0.25,0.5]])
print(cov_x)
x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=Num).T
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 2 -- t-distribution
err = t.rvs(df=4,size=Num,random_state=2).reshape(-1,1)/np.sqrt(2) #t-distribution
print(np.mean(err))
print(np.std(err))

y_0 = X_0 @ eta_t + err

# IC 状态参数估计
eta_0 = np.linalg.inv(X_0.T @ X_0) @ X_0.T @ y_0
sigma_0 = sigma_sum(X_0,y_0,eta_0)/Num

print(eta_0)
print(sigma_0)

#找控制线
nSimu = 10000 # 循环次数
nMaxRL = 3000 # ARL_0最大上限

def OLS_Limit(limitL,limitR,sig_IC,eta_IC,file_name,lam=0.1,size=20):
    """
       :param limitL: 控制线下线
       :param limitR: 控制线上限
       :param file_name:  保存文件名
       :param sig_IC: IC param
       :param eta_IC: IC param
       :return: 无
       """
    start_time = time.time()
    LimitL = limitL
    LimitR = limitR
    n = size
    sigma_0 = sig_IC
    eta_0 = eta_IC
    ARL = 220

    while abs(ARL - 200) >= 2 :
        Limit = (LimitL + LimitR) / 2
        RL = []
        for i in range(nSimu):
            O = (n / Num) * X_0.T @ X_0
            c_ = (n / Num) * X_0.T @ y_0
            C = sigma_0
            D = n * sigma_0

            k = 0
            Rlt = 0
            while (Rlt < Limit and k < nMaxRL):
                k += 1
                x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=n).T
                l_1 = np.array([1 for i in range(n)])
                X = np.vstack((l_1, x)).T
                err = t.rvs(df=4,size=n).reshape(-1,1)/np.sqrt(2)
                y = X @ eta_t + err

                O = (1 - lam) * O + lam * X.T @ X
                c_ = (1 - lam) * c_ + lam * X.T @ y
                Eeta = np.linalg.inv(O) @ c_

                Esigma = sigma_sum(X, y, Eeta) / n
                C = (1 - lam) * C + lam * Esigma

                V = sigma_sum(X, y, eta_0)
                D = (1 - lam) * D + lam * V

                Rlt = n * np.log(sigma_0) - n * np.log(C) + D / sigma_0 - n

            RL.append(k)
        ARL = np.mean(RL)
        StdRL = np.std(RL)/np.sqrt(nSimu)
        with open(file_name + '.txt', 'a') as file:
            file.write('ARL:\t{:.4f},\t{:.4f},\t{:.4f}\n'.format(ARL, StdRL, Limit))
        print('ARL:', ARL, StdRL, Limit)
        if (ARL < 200):
            LimitL = Limit
        else:
            LimitR = Limit
    end_time = time.time()
    run_time = end_time - start_time
    print("it  cost %s s for func running " % (round(run_time, 3)))

    with open(file_name + '.txt', 'a') as file:
        file.write("it  cost %s s for func running\n " % (round(run_time, 3)))

if __name__ == '__main__':
    file_name = './Limit/MR_limit_t'
    size = 20
    lam_d = 0.1
    print(size)
    print(lam_d)
    with open(file_name + '.txt', 'a') as file:
        file.write("n=20 t-student O^{-1} c_ \n")
    OLS_Limit(limitL=0.01,limitR=5.78,sig_IC=sigma_0,eta_IC=eta_0,file_name=file_name,lam=lam_d,size=size)


