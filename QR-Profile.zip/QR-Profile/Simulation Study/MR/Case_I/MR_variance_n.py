import numpy as np
from scipy.stats import multivariate_normal as M_n
import time

def sigma_sum(X,Y,beta):
    sig = Y - X @ beta
    return np.sum(sig ** 2)

p = 2
Num = 20000

# 真实模型参数
eta_t = np.array([3,2]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数
np.random.seed(2)
x = np.random.normal(loc=0,scale=0.5,size=Num)
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 1
err = np.random.normal(0, var_t, (Num, 1)) #normal errors

y_0 = X_0 @ eta_t + err

# IC 状态参数估计
eta_0 = np.linalg.inv(X_0.T @ X_0) @ X_0.T @ y_0
sigma_0 = sigma_sum(X_0,y_0,eta_0)/Num

print(eta_0)
print(sigma_0)


def OLS_sigma(limit, file_name,delta, lam=0.1, size=20):
    """

    :param limit: 控制线
    :param ld: EWMA系数
    :param N: 时间窗口宽度
    :param file_name:  保存文件名称
    :param shift_vec:  漂移向量
    :param shift_m:    漂移幅度
    :return:  无
    """
    nSimu = 10000  # 循环次数
    nMaxRL = 3000  # ARL_0最大上限

    Limit = limit  # 控制线
    n = size  # 样本个数
    print(delta)

    RL = []
    for i in range(nSimu):
        O = (n / Num) * X_0.T @ X_0
        c_ = (n / Num) * X_0.T @ y_0
        C = sigma_0
        D = n * sigma_0

        k = 0
        Rlt = 0
        while (Rlt < Limit and k < nMaxRL):
            k += 1
            x = np.random.normal(loc=0, scale=0.5, size=n)
            l_1 = np.array([1 for i in range(n)])
            X = np.vstack((l_1, x)).T
            err = np.random.normal(0, var_t, (n, 1))
            err_OC = (1 + delta) * err

            y = X @ eta_t + err_OC

            O = (1 - lam) * O + lam * X.T @ X
            c_ = (1 - lam) * c_ + lam * X.T @ y
            Eeta = np.linalg.inv(O) @ c_

            Esigma = sigma_sum(X, y, Eeta) / n
            C = (1 - lam) * C + lam * Esigma

            V = sigma_sum(X, y, eta_0)
            D = (1 - lam) * D + lam * V

            Rlt = n * np.log(sigma_0) - n * np.log(C) + D / sigma_0 - n

        RL.append(k)
    ARL = np.mean(RL)
    StdRL = np.std(RL) / np.sqrt(nSimu)
    with open(file_name + '.txt', 'a') as file:
        file.write("shift - %s \n" % (delta))
        file.write('ARL:\t{:.4f},\t{:.4f},\t{:.4f},\t{:.4f}\n'.format(ARL, StdRL, Limit, lam))
    print('ARL:', ARL, StdRL, Limit, lam)


if __name__ == '__main__':
    file_name = './ARL/MR_variance_n'

    with open(file_name + '.txt', 'a') as file:
        file.write("\n normal n=20 O^{-1} c_ *********************************************************************\n")

    #delta_list = [0,0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5] # [0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1]
    delta_list = [-0.5, -0.4, -0.3, -0.2, -0.1, -0.05, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5]
    size = 20
    lam_d = 0.1
    print(size)
    print(lam_d)

    limit = 0.796
    for i in delta_list:
        start_time = time.time()
        OLS_sigma(limit=limit, file_name=file_name, delta=i, lam=lam_d, size=size)
        end_time = time.time()
        run_time = end_time - start_time
        with open(file_name + '.txt', 'a') as file:
            file.write("it  cost %s s for func running\n " % (round(run_time, 3)))