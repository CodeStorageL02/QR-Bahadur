import matplotlib.pyplot as plt
import numpy as np
from matplotlib import rcParams


config = {
    "font.family":'Times New Roman',  # 设置字体类型
    "font.size":13,
    "mathtext.fontset":'stix'
}
rcParams.update(config)
T = [2,3,4,5,6,7,8,9,10,15,20]
T_1 = [2,3,4,5,6,7,8,9,10]
var_1_n=[33.2,	36.6,	42.3,	46.1,	49.8,	63.3,	94.4,	288, 348]
var_2_n=[40.6,	20.6,	18,	16.5,	16.9,	16.6,	16,	15.6,	15.3]
var_sum_n=[73.8,	57.2,	60.3,	62.6,	66.7,	79.9,	110.4,	303.6,363.3]
var_1_t=[76.6,	74.4,	70.1,	68.3,	88.7,	116,	303,	473,	559]
var_2_t=[36.9,	25.4,	24,	23.7,	23.5,	24.9,	23.8,	23.2,	23.3]
var_sum_t=[113.5,	99.8,	94.1,	92,	112.2,	140.9,	326.8,	496.2,	582.5]
var_1_chi=[19.2,	19.2,	19,	20.7,	27.8,	42.9,	75.9,	83.1,	247]
var_2_chi=[28.9,	18.2,	14.3,	12.8,	11.8,	10.9,	10.9,	9.48,	9.67]
var_sum_chi=[48.1,	37.4,	33.3,	33.5,	39.6,	53.8,	86.8,	92.58,	256.67]

S_N = np.zeros((9,9))
S_N[0,:] = var_1_n
S_N[1,:] = var_2_n
S_N[2,:] = var_sum_n
S_N[3,:] = var_1_t
S_N[4,:] = var_2_t
S_N[5,:] = var_sum_t
S_N[6,:] = var_1_chi
S_N[7,:] = var_2_chi
S_N[8,:] = var_sum_chi

#title_list = ["(a) $b_0$ with $\delta = -0.2$", "(b) $b_0$ with $\delta = 0.2$",
#              "(c) $b_1$ with $\delta = -0.2$", "(d) $b_1$ with $\delta = 0.2$",
#              "(e) $\omega$ with $\delta = -0.2$","(f) $\omega$ with $\delta = 0.2$"]
#fig = plt.figure(figsize=(15,8),dpi=100)

fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 6))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$T$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(2, 11, 2)))
ax1.plot(T_1, np.log(S_N[0,:]), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(T_1, np.log(S_N[1,:]), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.plot(T_1, np.log(S_N[2, :]), linestyle="-",label='Sum', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.15, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$T$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(2, 11, 2)))
ax2.plot(T_1, np.log(S_N[3, :]), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(T_1, np.log(S_N[4, :]), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.plot(T_1, np.log(S_N[5, :]), linestyle="-", label='Sum', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.15, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$T$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(2, 11, 2)))
ax3.plot(T_1, np.log(S_N[6, :]), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(T_1, np.log(S_N[7, :]), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.plot(T_1, np.log(S_N[8, :]), linestyle="-", label='Sum', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.15, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
#plt.savefig(r'.\M_Int.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()


d2_1_N = [72.2,49.1,45.8,66.9,71.7,79.4,82.2,82.6,82.3,87.9,94.9]
d2_2_N = [52.0,50.3,48.0,45.2,44.8,45.3,47.6,48.3,52.1,55.7,61.4]
d4_1_N = [71.3,51.5,53.9,61.5,60.6,71.0,74.6,78.2,83.7,84.4,88.4]
d4_2_N = [50.8,48.6,45.5,48.6,50.9,49.8,51.4,51.7,52.7,58.4,60.6]


d2_1_t = [41.5,38.9,38.1,48.9,60.1,57.1,71.4,69.9,66.8,94.1,116]
d2_2_t = [46.4,44.6,41.2,39.7,40.8,44.9,43.8,48.0,49.5,56.3,59.1]
d4_1_t = [45.2,43.6,42.6,48.0,48.5,49.8,53.0,54.9,54.2,58.3,61.6]
d4_2_t = [42.2,41.7,41.0,40.3,51.8,54.8,72.2,79.0,81.8,86.1,89.6]


d2_1_chi = [39.0,31.7,30.0,29.6,29.3,28.8,31.6,32.4,33.8,38.3,40.6]
d2_2_chi = [37.7,37.0,36.3,32.8,31.2,31.8,34.1,35.9,38.0,39.1,43.8]
d4_1_chi = [29.9,28.4,27.9,27.8,27.1,26.8,26.4,25.2,27.4,28.6,32.0]
d4_2_chi = [41.3,38.8,36.8,34.6,33.7,35.7,36.2,37.9,39.2,41.0,46.0]


#######
fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 6))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$T$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(2, 21, 2)))
ax1.plot(T, np.log(d2_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(T, np.log(d2_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.plot(T, np.log(np.array(d2_1_N) + np.array(d2_2_N)), linestyle="-",label='Sum', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.15, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$T$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(2, 21, 2)))
ax2.plot(T, np.log(d2_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(T, np.log(d2_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.plot(T, np.log(np.array(d2_1_t) + np.array(d2_2_t)), linestyle="-", label='Sum', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.15, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$T$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(2, 21, 2)))
ax3.plot(T, np.log(d2_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(T, np.log(d2_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.plot(T, np.log(np.array(d2_1_chi) + np.array(d2_2_chi)), linestyle="-", label='Sum', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.15, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
#plt.savefig(r'.\T_d2.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()

#####
#######
fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 6))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$T$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(2, 21, 2)))
ax1.plot(T, np.log(d4_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(T, np.log(d4_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.plot(T, np.log(np.array(d4_1_N) + np.array(d4_2_N)), linestyle="-",label='Sum', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.15, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$T$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(2, 21, 2)))
ax2.plot(T, np.log(d4_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(T, np.log(d4_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.plot(T, np.log(np.array(d4_1_t) + np.array(d4_2_t)), linestyle="-", label='Sum', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.15, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$T$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(2, 21, 2)))
ax3.plot(T, np.log(d4_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(T, np.log(d4_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.plot(T, np.log(np.array(d4_1_chi) + np.array(d4_2_chi)), linestyle="-", label='Sum', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.15, fontsize=14)
ax3.set_ylim(3,4.8)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
#plt.savefig(r'.\T_d4.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()