import numpy as np
from scipy.stats import multivariate_normal as M_n
import time
from IRLS import IRLS_List, generate_Omega
from scipy.stats import t


def interval(T):

    # 计算每个子区间的宽度
    left = 1/(2*T)
    right = 1 - 1/(2*T)

    # 计算每个子区间的中心点
    list = [left, 0.5, right]

    return list



T_list = [2,3,4,5,6,7,8,9,10,15,20]

k=-1
for K in T_list:
    tau_list = interval(K)
    print(K)
    print(tau_list)
    k = k + 1

    p = 5
    Num = 1000

    # 真实模型参数
    eta_t = np.array([2, 1, -3, -2, 4]).reshape(-1, 1)  # regression coefficient
    var_t = 1  # error variance

    # 训练数据,用于估计 Phase I 参数 Multiple
    np.random.seed(2)
    mean_x = np.zeros(p - 1)
    cov_x = np.array(
        [[0.5, 0.25, 0.125, 0.0625], [0.25, 0.5, 0.25, 0.125], [0.125, 0.25, 0.5, 0.25], [0.0625, 0.125, 0.25, 0.5]])
    print(cov_x)
    x = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=Num).T
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x)).T

    # 随机误差
    # Sceniro 1
    err = np.random.normal(0, var_t, (Num, 1))  # normal errors

    y_0 = X_0 @ eta_t + err

    # IC 状态参数估计

    Cov = X_0.T @ X_0 / Num
    Omega = generate_Omega(p, tau_list, Cov)
    print(Omega.shape)
    Omega_inv = np.linalg.inv(Omega)

    Beta_0 = IRLS_List(y_0, X_0, tau_list)
    print(Beta_0)


    def QR_sigma(limit, file_name, delta, lam=0.1, size=20):
        """

        :param limit: 控制线
        :param ld: EWMA系数
        :param N: 时间窗口宽度
        :param file_name:  保存文件名称
        :return:  无
        """
        nSimu = 10000  # 循环次数
        nMaxRL = 3000  # ARL_0最大上限

        Limit = limit  # 控制线
        n = size  # 样本个数
        print(delta)

        RL = []
        for i in range(nSimu):
            w = np.zeros((len(tau_list), p))

            k = 0
            Rlt = 0
            while (Rlt < Limit and k < nMaxRL):
                k += 1
                x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=n).T
                l_1 = np.array([1 for i in range(n)])
                X = np.vstack((l_1, x)).T
                err = np.random.normal(0, var_t, (n, 1))
                err_OC = (1 + delta) * err

                y = X @ eta_t + err_OC
                for a in range(len(tau_list)):
                    res = np.squeeze(y) - X @ Beta_0[:, a]
                    resid = np.where(res < 0, tau_list[a] - 1, tau_list[a])
                    z = np.sum(X.T * resid, axis=1) / n
                    w[a, :] = (1 - lam) * w[a, :] + lam * z
                w_vec = w.flatten('C')
                Rlt = n * w_vec @ Omega_inv @ w_vec.T

            RL.append(k)
        ARL = np.mean(RL)
        StdRL = np.std(RL) / np.sqrt(nSimu)
        with open(file_name + '.txt', 'a') as file:
            file.write("shift - %s \n" % (delta))
            file.write('ARL:\t{:.4f},\t{:.4f},\t{:.4f},\t{:.4f}\n'.format(ARL, StdRL, Limit, lam))
        print('ARL:', ARL, StdRL, Limit, lam)


    file_name = './ARL/QR_variance_n'
    with open(file_name + '.txt', 'a') as file:
        file.write("n=20 T= %s\n *********************************************************************\n"% (K))

    delta_list = [-0.2,0.2]
    size = 20
    lam_d = 0.1
    print(size)
    print(lam_d)
    limit_list = [2.013,2.208,2.343,2.436,2.488,2.646,2.977,2.956,2.742,2.807,3.367]
    #[1.966, 1.831,1.8081,1.9851,1.9292,2.0526,2.0876,2.2692,2.2459,2.3205, 2.1509]
    limit = limit_list[k]
    print(k)
    print(limit_list)
    for i in delta_list:
        start_time = time.time()
        QR_sigma(limit=limit, file_name=file_name, delta=i, lam=lam_d, size=size)
        end_time = time.time()
        run_time = end_time - start_time
        with open(file_name + '.txt', 'a') as file:
            file.write("it  cost %s s for func running\n " % (round(run_time, 3)))