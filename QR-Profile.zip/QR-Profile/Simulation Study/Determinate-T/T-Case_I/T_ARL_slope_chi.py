import numpy as np
from scipy.stats import multivariate_normal as M_n
import time
from IRLS import IRLS_List, generate_Omega
from scipy.stats import t


def interval(T):

    # 计算每个子区间的宽度
    left = 1/(2*T)
    right = 1 - 1/(2*T)

    # 计算每个子区间的中心点
    list = [left, 0.5, right]

    return list



T_list = [2,3,4,5,6,7,8,9,10,15,20]

kk=-1
for T in T_list:
    tau_list = interval(T)
    print(T)
    print(tau_list)
    kk = kk + 1

    p = 2
    Num = 1000

    # 真实模型参数
    eta_t = np.array([3, 2]).reshape(-1, 1)  # regression coefficient
    var_t = 1  # error variance

    # 训练数据,用于估计 Phase I 参数
    np.random.seed(25)  # 2
    x = np.random.normal(loc=0, scale=0.5, size=Num)
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x)).T

    # 随机误差
    # Sceniro 3 chi
    err = (np.random.chisquare(4, Num).reshape(-1, 1) - 4) / (2 * np.sqrt(2))
    print(np.mean(err))
    print(np.std(err))
    y_0 = X_0 @ eta_t + err


    # IC 状态参数估计

    Cov = X_0.T @ X_0 / Num
    Omega = generate_Omega(p, tau_list, Cov)
    print(Omega.shape)
    Omega_inv = np.linalg.inv(Omega)

    Beta_0 = IRLS_List(y_0, X_0, tau_list)
    print(Beta_0)


    def QR_Sum_beta(limit, file_name, eta_OC, lam=0.1, size=20):
        """

        :param limit: 控制线
        :param ld: EWMA系数
        :param N: 时间窗口宽度
        :param file_name:  保存文件名称
        :param eta_OC:
        :return:  无
        """
        nSimu = 10000  # 循环次数
        nMaxRL = 3000  # ARL_0最大上限

        Limit = limit  # 控制线
        n = size  # 样本个数

        print(eta_OC)

        RL = []
        for i in range(nSimu):
            w = np.zeros((len(tau_list), p))

            k = 0
            Rlt = 0
            while (Rlt < Limit and k < nMaxRL):
                k += 1
                x = np.random.normal(loc=0, scale=0.5, size=n)
                l_1 = np.array([1 for i in range(n)])
                X = np.vstack((l_1, x)).T
                err = (np.random.chisquare(4, n).reshape(-1, 1) - 4) / (2 * np.sqrt(2))

                y = X @ eta_OC + err

                for a in range(len(tau_list)):
                    res = np.squeeze(y) - X @ Beta_0[:, a]
                    resid = np.where(res < 0, tau_list[a] - 1, tau_list[a])
                    z = np.sum(X.T * resid, axis=1) / n
                    w[a, :] = (1 - lam) * w[a, :] + lam * z
                w_vec = w.flatten('C')
                Rlt = n * w_vec @ Omega_inv @ w_vec.T

            RL.append(k)
        ARL = np.mean(RL)
        StdRL = np.std(RL) / np.sqrt(nSimu)
        with open(file_name + '.txt', 'a') as file:
            file.write("shift - %s \n" % (eta_OC - eta_t))
            file.write('ARL:\t{:.4f},\t{:.4f},\t{:.4f},\t{:.4f}\n'.format(ARL, StdRL, Limit, lam))
        print('ARL:', ARL, StdRL, Limit, lam)


    file_name = './ARL/QR_slope_chi'

    shift_list = [0]#[-0.2, 0.2]
    size = 20
    lam_d = 0.1
    print(size)
    print(lam_d)
    limit_list = [0.858, 0.9474, 1.08, 1.009, 1.1286, 1.219, 1.1839, 1.2745, 1.2126, 1.371, 1.673]
    limit = limit_list[kk]
    print(kk)
    print(limit_list)
    shift_mat = np.eye(p)
    with open(file_name + '.txt', 'a') as file:
        file.write("n=20  T= %s \t #########################################################################\n" % (T) )
    for j in range(p):
        with open(file_name + '.txt', 'a') as file:
            file.write("beta%s n=20 ************************************************ \n" % (j + 1))
        shift_vec = shift_mat[j, :].reshape(-1, 1)
        for i in shift_list:
            eta_OC = shift_vec * i + eta_t
            start_time = time.time()
            QR_Sum_beta(limit=limit, file_name=file_name, eta_OC=eta_OC, lam=lam_d, size=size)
            end_time = time.time()
            run_time = end_time - start_time
            with open(file_name + '.txt', 'a') as file:
                file.write("it  cost %s s for func running\n " % (round(run_time, 3)))

