import matplotlib.pyplot as plt
import numpy as np
from matplotlib import rcParams


config = {
    "font.family":'Times New Roman',  # 设置字体类型
    "font.size":13,
    "mathtext.fontset":'stix'
}
rcParams.update(config)
T = [2,3,4,5,6,7,8,9,10,15,20]

var_1_n=[28.9,28.4,26.6,21,	17.7,27.8,28.5,37.9,37,82.5,704]
var_2_n=[20.5,	16.3,	15.1,	14.6,	14.4,	14.6,	14,	12.9,	11.6,	11.3,	11.4]
var_sum_n=[49.4,	44.7,	41.7,	35.6,	32.1,	42.4,	42.5,	50.8,	48.6,	93.8,	715.4]
var_1_t=[21.7,	20.8,	18.1,	16.5,	20.5,	24.2,	31.8,	42.2,	64.8,	308,	1113]
var_2_t=[30.8,	29.1,	27.9,	28.3,	23.3,	19.7,	18.5,	17.9,	17.3,	18.9,	17.8]
var_sum_t=[52.5,	49.9,	46,	44.8,	43.8,	43.9,	50.3,	60.1,	82.1,	326.9,	1130.8]
var_1_chi=[10.8,	10.9,	10.9,	11,	12.9,	16.1,	17.4,	23.5,	24.3,	112,	1087]
var_2_chi=[19.1,	12.5,	11.2,	9.8,	9.01,	8.49,	7.71,	7.8,	7.19,	6.88,	6.94]
var_sum_chi=[29.9,	23.4,	22.1,	20.8,	21.91,	24.59,	25.11,	31.3,	31.49,	118.88,	1093.94]

S_N = np.zeros((9,11))
S_N[0,:] = var_1_n
S_N[1,:] = var_2_n
S_N[2,:] = var_sum_n
S_N[3,:] = var_1_t
S_N[4,:] = var_2_t
S_N[5,:] = var_sum_t
S_N[6,:] = var_1_chi
S_N[7,:] = var_2_chi
S_N[8,:] = var_sum_chi

#title_list = ["(a) $b_0$ with $\delta = -0.2$", "(b) $b_0$ with $\delta = 0.2$",
#              "(c) $b_1$ with $\delta = -0.2$", "(d) $b_1$ with $\delta = 0.2$",
#              "(e) $\omega$ with $\delta = -0.2$","(f) $\omega$ with $\delta = 0.2$"]
#fig = plt.figure(figsize=(15,8),dpi=100)

fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 6))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$T$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(2, 21, 2)))
ax1.plot(T, np.log(S_N[0,:]), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(T, np.log(S_N[1,:]), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.plot(T, np.log(S_N[2, :]), linestyle="-",label='Sum', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.15, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$T$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(2, 21, 2)))
ax2.plot(T, np.log(S_N[3, :]), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(T, np.log(S_N[4, :]), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.plot(T, np.log(S_N[5, :]), linestyle="-", label='Sum', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.15, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$T$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(2, 21, 2)))
ax3.plot(T, np.log(S_N[6, :]), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(T, np.log(S_N[7, :]), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.plot(T, np.log(S_N[8, :]), linestyle="-", label='Sum', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.15, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
#plt.savefig(r'.\S_Int.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()


b0_1_N = [22.7,21.5,20.8,23.8,31.5,31.8,31.7,31.9,34.8,36.0,38.0]
b0_2_N = [19.2,18.6,17.9,16.6,17.4,18.2,18.3,18.8,19.0,21.6,28.0]
b1_1_N = [77.2,78,76.4,75.7,101,118,123,130,134,146,153]
b1_2_N = [57.9,54.8,52.5,51.5,50.7,50.1,49.1,53.0,56.8,59.2,61.8]


b0_1_t = [15.5,14.8,14.0,13.8,14.9,15.4,15.7,15.8,16.5,18.7,22.5]
b0_2_t = [15.1,14.1,13.2,14.3,14.9,15.6,16.5,16.7,17.6,19.5,21.8]
b1_1_t = [44.7,37.4,41.9,42.0,43.4,44.2,46.1,47.3,48.2,51.2,56.5]
b1_2_t = [55.1,53.0,48.7,48.1,44.5,47.2,47.9,49.1,53.7,70.9,85.0]


b0_1_chi = [13.3,11.4,11.4,10.1,9.49,9.66,9.8,10.0,10.8,10.9,11.9]
b0_2_chi = [12.4,11.3,11.0,10.9,13.3,14.5,15.0,15.7,15.9,20.4,27.0]
b1_1_chi = [47.9,36.8,38.4,46.7,49.2,50.2,53.5,56.7,57.3,59.1,69.6]
b1_2_chi = [34.1,32.9,30.1,27.2,25.4,26.2,28.9,29.7,30.9,31.7,33.5]

#######
fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15,6))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$T$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(2, 21, 2)))
ax1.plot(T, np.log(b0_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(T, np.log(b0_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.plot(T, np.log(np.array(b0_1_N) + np.array(b0_2_N)), linestyle="-",label='Sum', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.15, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$T$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(2, 21, 2)))
ax2.plot(T, np.log(b0_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(T, np.log(b0_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.plot(T, np.log(np.array(b0_1_t) + np.array(b0_2_t)), linestyle="-", label='Sum', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.15, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$T$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(2, 21, 2)))
ax3.plot(T, np.log(b0_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(T, np.log(b0_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.plot(T, np.log(np.array(b0_1_chi) + np.array(b0_2_chi)), linestyle="-", label='Sum', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.15, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
#plt.savefig(r'.\T_b0.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()

#####
#######
fig,(ax1,ax2,ax3) = plt.subplots(1, 3, figsize=(15, 6))

ax1.spines['top'].set_color('none')
ax1.spines['right'].set_color('none')

ax1.set_xlabel('$T$')
ax1.set_ylabel('ln(ARL)')
ax1.set_xticks(list(np.arange(2, 21, 2)))
ax1.plot(T, np.log(b1_1_N), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax1.plot(T, np.log(b1_2_N), linestyle="-.",label='$\delta = 0.2 $', linewidth=2)
ax1.plot(T, np.log(np.array(b1_1_N) + np.array(b1_2_N)), linestyle="-",label='Sum', linewidth=2)
ax1.set_title("(a) N(0,1)",y=-0.15, fontsize=14)
ax1.legend()

ax2.spines['top'].set_color('none')
ax2.spines['right'].set_color('none')

ax2.set_xlabel('$T$')
ax2.set_ylabel('ln(ARL)')
ax2.set_xticks(list(np.arange(2, 21, 2)))
ax2.plot(T, np.log(b1_1_t), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax2.plot(T, np.log(b1_2_t), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax2.plot(T, np.log(np.array(b1_1_t) + np.array(b1_2_t)), linestyle="-", label='Sum', linewidth=2)
ax2.set_title("(b) $t(4)/\sqrt{2}$",y=-0.15, fontsize=14)
ax2.legend()

ax3.spines['top'].set_color('none')
ax3.spines['right'].set_color('none')

ax3.set_xlabel('$T$')
ax3.set_ylabel('ln(ARL)')
ax3.set_xticks(list(np.arange(2, 21, 2)))
ax3.plot(T, np.log(b1_1_chi), linestyle="--", label='$\delta = -0.2 $', linewidth=2)
ax3.plot(T, np.log(b1_2_chi), linestyle="-.", label='$\delta = 0.2 $', linewidth=2)
ax3.plot(T, np.log(np.array(b1_1_chi) + np.array(b1_2_chi)), linestyle="-", label='Sum', linewidth=2)
ax3.set_title("(c) $(\chi^2(4)-4)/2\sqrt{2}$",y=-0.15, fontsize=14)
ax3.legend()

plt.tight_layout()
plt.margins(0.1, 0.1)
#plt.savefig(r'.\T_b1.png', pad_inches=0.1,dpi=300, bbox_inches='tight')
plt.show()