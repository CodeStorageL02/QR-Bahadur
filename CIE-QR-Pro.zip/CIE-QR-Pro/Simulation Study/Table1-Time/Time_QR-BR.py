import numpy as np
import time
from IRLS import IRLS_List, generate_Omega
from scipy.stats import t

p = 2
Num = 1000

nSimu = 10000

file_name = 'QR_BR_time'
n=20
lam = 0.1
##  Case I


# normal

# 真实模型参数
eta_t = np.array([3, 2]).reshape(-1, 1)  # regression coefficient
var_t = 1  # error variance

# 训练数据,用于估计 Phase I 参数
np.random.seed(2)  # 2
x = np.random.normal(loc=0, scale=0.5, size=Num)
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 1
err = np.random.normal(0, var_t, (Num, 1)) #normal errors


y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau_list = [0.1, 0.5, 0.9]
Cov = X_0.T @ X_0 / Num
Omega = generate_Omega(p, tau_list, Cov)
print(Omega.shape)
Omega_inv = np.linalg.inv(Omega)

Beta_0 = IRLS_List(y_0, X_0, tau_list)
print(Beta_0)

w = np.zeros((len(tau_list), p))
start_time = time.time()
for _ in range(nSimu):

    x = np.random.normal(loc=0, scale=0.5, size=n)
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = np.random.normal(0, var_t, (n, 1))
    y = X @ eta_t + err

    for a in range(len(tau_list)):
        res = np.squeeze(y) - X @ Beta_0[:, a]
        resid = np.where(res < 0, tau_list[a] - 1, tau_list[a])
        z = np.sum(X.T * resid, axis=1) / n
        w[a, :] = (1 - lam) * w[a, :] + lam * z
        w_vec = w.flatten('C')
        Rlt = n * w_vec @ Omega_inv @ w_vec.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for normal  in Case I\n " % (run_time / nSimu))


# t 

# 真实模型参数
eta_t = np.array([3,2]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数
np.random.seed(2) # 2
x = np.random.normal(loc=0,scale=0.5,size=Num)
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 2 -- t-distribution
err = t.rvs(df=4,size=Num,random_state=9).reshape(-1,1)/np.sqrt(2) #t-distribution
print(np.mean(err))
print(np.std(err))

y_0 = X_0 @ eta_t + err


# IC 状态参数估计
tau_list = [0.1, 0.5, 0.9]
Cov = X_0.T @ X_0/Num
Omega = generate_Omega(p,tau_list,Cov)
print(Omega.shape)
Omega_inv = np.linalg.inv(Omega)

Beta_0 = IRLS_List(y_0,X_0,tau_list)
print(Beta_0)

w = np.zeros((len(tau_list), p))
start_time = time.time()
for _ in range(nSimu):

    x = np.random.normal(loc=0, scale=0.5, size=n)
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = t.rvs(df=4,size=n).reshape(-1,1)/np.sqrt(2)
    y = X @ eta_t + err

    for a in range(len(tau_list)):
        res = np.squeeze(y) - X @ Beta_0[:, a]
        resid = np.where(res < 0, tau_list[a] - 1, tau_list[a])
        z = np.sum(X.T * resid, axis=1) / n
        w[a, :] = (1 - lam) * w[a, :] + lam * z
        w_vec = w.flatten('C')
        Rlt = n * w_vec @ Omega_inv @ w_vec.T
        
end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for t  in Case I\n " % (run_time/nSimu))

# chi 

# 真实模型参数
eta_t = np.array([3, 2]).reshape(-1, 1)  # regression coefficient
var_t = 1  # error variance

# 训练数据,用于估计 Phase I 参数
np.random.seed(2)  # 2
x = np.random.normal(loc=0, scale=0.5, size=Num)
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 3 chi
err = (np.random.chisquare(4, Num).reshape(-1,1) - 4)/(2*np.sqrt(2))
print(np.mean(err))
print(np.std(err))

y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau_list = [0.1, 0.5, 0.9]
Cov = X_0.T @ X_0 / Num
Omega = generate_Omega(p, tau_list, Cov)
print(Omega.shape)
Omega_inv = np.linalg.inv(Omega)

Beta_0 = IRLS_List(y_0, X_0, tau_list)
print(Beta_0)

w = np.zeros((len(tau_list), p))
start_time = time.time()
for _ in range(nSimu):

    x = np.random.normal(loc=0, scale=0.5, size=n)
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = (np.random.chisquare(4, n).reshape(-1, 1) - 4) / (2 * np.sqrt(2))
    y = X @ eta_t + err

    for a in range(len(tau_list)):
        res = np.squeeze(y) - X @ Beta_0[:, a]
        resid = np.where(res < 0, tau_list[a] - 1, tau_list[a])
        z = np.sum(X.T * resid, axis=1) / n
        w[a, :] = (1 - lam) * w[a, :] + lam * z
        w_vec = w.flatten('C')
        Rlt = n * w_vec @ Omega_inv @ w_vec.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for t  in Case I\n " % (run_time / nSimu))

##  Case II

p = 5
# normal

# 真实模型参数
eta_t = np.array([2,1,-3,-2,4]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数 Multiple
np.random.seed(2)
mean_x = np.zeros(p-1)
cov_x = np.array([[0.5,0.25,0.125,0.0625],[0.25,0.5,0.25,0.125],[0.125,0.25,0.5,0.25],[0.0625,0.125,0.25,0.5]])
print(cov_x)
x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=Num).T
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
# Sceniro 1
err = np.random.normal(0, var_t, (Num, 1))  # normal errors

y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau_list = [0.1, 0.5, 0.9]
Cov = X_0.T @ X_0 / Num
Omega = generate_Omega(p, tau_list, Cov)
print(Omega.shape)
Omega_inv = np.linalg.inv(Omega)

Beta_0 = IRLS_List(y_0, X_0, tau_list)
print(Beta_0)

w = np.zeros((len(tau_list), p))
start_time = time.time()
for _ in range(nSimu):

    x = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=n).T
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = np.random.normal(0, var_t, (n, 1))
    y = X @ eta_t + err

    for a in range(len(tau_list)):
        res = np.squeeze(y) - X @ Beta_0[:, a]
        resid = np.where(res < 0, tau_list[a] - 1, tau_list[a])
        z = np.sum(X.T * resid, axis=1) / n
        w[a, :] = (1 - lam) * w[a, :] + lam * z
        w_vec = w.flatten('C')
        Rlt = n * w_vec @ Omega_inv @ w_vec.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for normal  in Case II\n " % (run_time / nSimu))

# t 

# 真实模型参数
eta_t = np.array([2,1,-3,-2,4]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数 Multiple
np.random.seed(2)
mean_x = np.zeros(p-1)
cov_x = np.array([[0.5,0.25,0.125,0.0625],[0.25,0.5,0.25,0.125],[0.125,0.25,0.5,0.25],[0.0625,0.125,0.25,0.5]])
print(cov_x)
x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=Num).T
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
# Sceniro 2 -- t-distribution
err = t.rvs(df=4, size=Num, random_state=9).reshape(-1, 1) / np.sqrt(2)  # t-distribution
print(np.mean(err))
print(np.std(err))

y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau_list = [0.1, 0.5, 0.9]
Cov = X_0.T @ X_0 / Num
Omega = generate_Omega(p, tau_list, Cov)
print(Omega.shape)
Omega_inv = np.linalg.inv(Omega)

Beta_0 = IRLS_List(y_0, X_0, tau_list)
print(Beta_0)

w = np.zeros((len(tau_list), p))
start_time = time.time()
for _ in range(nSimu):

    x = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=n).T
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = t.rvs(df=4, size=n).reshape(-1, 1) / np.sqrt(2)
    y = X @ eta_t + err

    for a in range(len(tau_list)):
        res = np.squeeze(y) - X @ Beta_0[:, a]
        resid = np.where(res < 0, tau_list[a] - 1, tau_list[a])
        z = np.sum(X.T * resid, axis=1) / n
        w[a, :] = (1 - lam) * w[a, :] + lam * z
        w_vec = w.flatten('C')
        Rlt = n * w_vec @ Omega_inv @ w_vec.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for t  in Case II\n " % (run_time / nSimu))

# chi 

# 真实模型参数
eta_t = np.array([2,1,-3,-2,4]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数 Multiple
np.random.seed(2)
mean_x = np.zeros(p-1)
cov_x = np.array([[0.5,0.25,0.125,0.0625],[0.25,0.5,0.25,0.125],[0.125,0.25,0.5,0.25],[0.0625,0.125,0.25,0.5]])
print(cov_x)
x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=Num).T
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
# Sceniro 3 chi
err = (np.random.chisquare(4, Num).reshape(-1, 1) - 4) / (2 * np.sqrt(2))
print(np.mean(err))
print(np.std(err))

y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau_list = [0.1, 0.5, 0.9]
Cov = X_0.T @ X_0 / Num
Omega = generate_Omega(p, tau_list, Cov)
print(Omega.shape)
Omega_inv = np.linalg.inv(Omega)

Beta_0 = IRLS_List(y_0, X_0, tau_list)
print(Beta_0)

w = np.zeros((len(tau_list), p))
start_time = time.time()
for _ in range(nSimu):

    x = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=n).T
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = (np.random.chisquare(4, n).reshape(-1, 1) - 4) / (2 * np.sqrt(2))
    y = X @ eta_t + err

    for a in range(len(tau_list)):
        res = np.squeeze(y) - X @ Beta_0[:, a]
        resid = np.where(res < 0, tau_list[a] - 1, tau_list[a])
        z = np.sum(X.T * resid, axis=1) / n
        w[a, :] = (1 - lam) * w[a, :] + lam * z
        w_vec = w.flatten('C')
        Rlt = n * w_vec @ Omega_inv @ w_vec.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for chi  in Case II\n " % (run_time / nSimu))