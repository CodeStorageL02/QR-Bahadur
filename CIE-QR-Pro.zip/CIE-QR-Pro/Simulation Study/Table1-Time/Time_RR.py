import numpy as np
from related_functions import wilcoxon_rank,spacial_sign_R
import time
from scipy.stats import t

def sigma_sum(X,Y,beta,a):
    sig = Y - X @ beta - a
    return np.sum(sig ** 2)


nSimu = 10000

file_name = 'Rank_time'
n=20
lam = 0.1

p = 2
Num = 20
m=50

Z_matrix = np.zeros((m,p+1))

##  Case I

# normal

# 真实模型参数
eta_t = np.array([3,2]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数
np.random.seed(2) # 25

for s in range(m):

    x = np.random.normal(loc=0,scale=0.5,size=Num)
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x)).T

# 随机误差
    # Sceniro 1
    err = np.random.normal(0, var_t, (Num, 1))  # normal errors

    y_0 = X_0 @ eta_t + err

# IC 状态参数估计

    a_0 = np.mean(y_0)

    b_1 = wilcoxon_rank(x.reshape(-1,1),np.squeeze(y_0))

    sigma_0 = sigma_sum(x.reshape(-1,1),y_0,b_1.reshape(-1,1),a_0)/(Num-p)
    z = np.concatenate([[a_0], np.array(b_1), [sigma_0]])
    Z_matrix[s, :] = z
print(Z_matrix.shape)

med, S = spacial_sign_R(Z_matrix)

w = np.zeros(p + 1)
start_time = time.time()
for _ in range(nSimu):
    x = np.random.normal(loc=0, scale=0.5, size=n)
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = np.random.normal(0, var_t, (n, 1))
    y = X @ eta_t + err

    a_c = np.mean(y)

    b_1_c = wilcoxon_rank(x.reshape(-1, 1), np.squeeze(y))

    sigma_c = sigma_sum(x.reshape(-1, 1), y, b_1_c.reshape(-1, 1), a_c) / (n - p)

    z = np.concatenate([[a_c], np.array(b_1_c), [sigma_c]])

    z = (z - med) @ S.T
    z = z / np.linalg.norm(z)
    w = (1 - lam) * w + lam * z

    Rlt = (2 - lam) / lam * (p + 1) * w @ w.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for normal  in Case I\n " % (run_time / nSimu))


# t

# 真实模型参数
eta_t = np.array([3,2]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数
np.random.seed(2) # 25

for s in range(m):

    x = np.random.normal(loc=0,scale=0.5,size=Num)
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x)).T

# 随机误差
    # Sceniro 2 -- t-distribution
    err = t.rvs(df=4, size=Num).reshape(-1, 1) / np.sqrt(2)  # t-distribution

    y_0 = X_0 @ eta_t + err

# IC 状态参数估计

    a_0 = np.mean(y_0)

    b_1 = wilcoxon_rank(x.reshape(-1,1),np.squeeze(y_0))

    sigma_0 = sigma_sum(x.reshape(-1,1),y_0,b_1.reshape(-1,1),a_0)/(Num-p)
    z = np.concatenate([[a_0], np.array(b_1), [sigma_0]])
    Z_matrix[s, :] = z
print(Z_matrix.shape)

med, S = spacial_sign_R(Z_matrix)

w = np.zeros(p + 1)
start_time = time.time()
for _ in range(nSimu):
    x = np.random.normal(loc=0, scale=0.5, size=n)
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = t.rvs(df=4, size=n).reshape(-1, 1) / np.sqrt(2)
    y = X @ eta_t + err

    a_c = np.mean(y)

    b_1_c = wilcoxon_rank(x.reshape(-1, 1), np.squeeze(y))

    sigma_c = sigma_sum(x.reshape(-1, 1), y, b_1_c.reshape(-1, 1), a_c) / (n - p)

    z = np.concatenate([[a_c], np.array(b_1_c), [sigma_c]])

    z = (z - med) @ S.T
    z = z / np.linalg.norm(z)
    w = (1 - lam) * w + lam * z

    Rlt = (2 - lam) / lam * (p + 1) * w @ w.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for t  in Case I\n " % (run_time / nSimu))


# chi

# 真实模型参数
eta_t = np.array([3,2]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数
np.random.seed(2) # 25

for s in range(m):

    x = np.random.normal(loc=0,scale=0.5,size=Num)
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x)).T

# 随机误差
    # Sceniro 3 chi
    err = (np.random.chisquare(4, Num).reshape(-1, 1) - 4) / (2 * np.sqrt(2))

    y_0 = X_0 @ eta_t + err

# IC 状态参数估计

    a_0 = np.mean(y_0)

    b_1 = wilcoxon_rank(x.reshape(-1,1),np.squeeze(y_0))

    sigma_0 = sigma_sum(x.reshape(-1,1),y_0,b_1.reshape(-1,1),a_0)/(Num-p)
    z = np.concatenate([[a_0], np.array(b_1), [sigma_0]])
    Z_matrix[s, :] = z
print(Z_matrix.shape)

med, S = spacial_sign_R(Z_matrix)

w = np.zeros(p + 1)
start_time = time.time()
for _ in range(nSimu):
    x = np.random.normal(loc=0, scale=0.5, size=n)
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = (np.random.chisquare(4, n).reshape(-1, 1) - 4) / (2 * np.sqrt(2))
    y = X @ eta_t + err

    a_c = np.mean(y)

    b_1_c = wilcoxon_rank(x.reshape(-1, 1), np.squeeze(y))

    sigma_c = sigma_sum(x.reshape(-1, 1), y, b_1_c.reshape(-1, 1), a_c) / (n - p)

    z = np.concatenate([[a_c], np.array(b_1_c), [sigma_c]])

    z = (z - med) @ S.T
    z = z / np.linalg.norm(z)
    w = (1 - lam) * w + lam * z

    Rlt = (2 - lam) / lam * (p + 1) * w @ w.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for chi  in Case I\n " % (run_time / nSimu))


##  Case II
p=5
# 真实模型参数
eta_t = np.array([2,1,-3,-2,4]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数 Multiple
np.random.seed(2)

Z_matrix = np.zeros((m, p + 1))

mean_x = np.zeros(p-1)
cov_x = np.array([[0.5,0.25,0.125,0.0625],[0.25,0.5,0.25,0.125],[0.125,0.25,0.5,0.25],[0.0625,0.125,0.25,0.5]])


# normal


for s in range(m):
    x_0 = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=Num).T
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x_0)).T

    # 随机误差
    # Sceniro 1
    err = np.random.normal(0, var_t, (Num, 1))  # normal errors

    y_0 = X_0 @ eta_t + err

    # IC 状态参数估计

    a_0 = np.mean(y_0)

    b_1 = wilcoxon_rank(x_0.T, np.squeeze(y_0))

    sigma_0 = sigma_sum(x_0.T, y_0, b_1.reshape(-1, 1), a_0) / (Num - p)
    z = np.concatenate([[a_0], np.array(b_1), [sigma_0]])
    Z_matrix[s, :] = z
print(Z_matrix.shape)

med, S = spacial_sign_R(Z_matrix)

w = np.zeros(p + 1)
start_time = time.time()
for _ in range(nSimu):
    x = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=n).T
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = np.random.normal(0, var_t, (n, 1))
    y = X @ eta_t + err

    a_c = np.mean(y)

    b_1_c = wilcoxon_rank(x.T, np.squeeze(y))

    sigma_c = sigma_sum(x.T, y, b_1_c.reshape(-1, 1), a_c) / (n - p)

    z = np.concatenate([[a_c], np.array(b_1_c), [sigma_c]])

    z = (z - med) @ S.T
    z = z / np.linalg.norm(z)
    w = (1 - lam) * w + lam * z

    Rlt = (2 - lam) / lam * (p + 1) * w @ w.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for normal  in Case II\n " % (run_time / nSimu))

# t


for s in range(m):
    x_0 = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=Num).T
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x_0)).T

    # 随机误差
    # Sceniro 2 -- t-distribution
    err = t.rvs(df=4, size=Num).reshape(-1, 1) / np.sqrt(2)  # t-distribution

    y_0 = X_0 @ eta_t + err

    # IC 状态参数估计

    a_0 = np.mean(y_0)

    b_1 = wilcoxon_rank(x_0.T, np.squeeze(y_0))

    sigma_0 = sigma_sum(x_0.T, y_0, b_1.reshape(-1, 1), a_0) / (Num - p)
    z = np.concatenate([[a_0], np.array(b_1), [sigma_0]])
    Z_matrix[s, :] = z
print(Z_matrix.shape)

med, S = spacial_sign_R(Z_matrix)

w = np.zeros(p + 1)
start_time = time.time()
for _ in range(nSimu):
    x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=n).T
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = t.rvs(df=4, size=n).reshape(-1, 1) / np.sqrt(2)
    y = X @ eta_t + err

    a_c = np.mean(y)

    b_1_c = wilcoxon_rank(x.T, np.squeeze(y))

    sigma_c = sigma_sum(x.T, y, b_1_c.reshape(-1, 1), a_c) / (n - p)

    z = np.concatenate([[a_c], np.array(b_1_c), [sigma_c]])

    z = (z - med) @ S.T
    z = z / np.linalg.norm(z)
    w = (1 - lam) * w + lam * z

    Rlt = (2 - lam) / lam * (p + 1) * w @ w.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for t  in Case II\n " % (run_time / nSimu))

# chi


for s in range(m):
    x_0 = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=Num).T
    l_1 = np.array([1 for i in range(Num)])
    X_0 = np.vstack((l_1, x_0)).T

    # 随机误差
    # Sceniro 3 chi
    err = (np.random.chisquare(4, Num).reshape(-1, 1) - 4) / (2 * np.sqrt(2))

    y_0 = X_0 @ eta_t + err

    # IC 状态参数估计

    a_0 = np.mean(y_0)

    b_1 = wilcoxon_rank(x_0.T, np.squeeze(y_0))

    sigma_0 = sigma_sum(x_0.T, y_0, b_1.reshape(-1, 1), a_0) / (Num - p)
    z = np.concatenate([[a_0], np.array(b_1), [sigma_0]])
    Z_matrix[s, :] = z
print(Z_matrix.shape)

med, S = spacial_sign_R(Z_matrix)

w = np.zeros(p + 1)
start_time = time.time()
for _ in range(nSimu):
    x = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=n).T
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = (np.random.chisquare(4, n).reshape(-1, 1) - 4) / (2 * np.sqrt(2))
    y = X @ eta_t + err

    a_c = np.mean(y)

    b_1_c = wilcoxon_rank(x.T, np.squeeze(y))

    sigma_c = sigma_sum(x.T, y, b_1_c.reshape(-1, 1), a_c) / (n - p)

    z = np.concatenate([[a_c], np.array(b_1_c), [sigma_c]])

    z = (z - med) @ S.T
    z = z / np.linalg.norm(z)
    w = (1 - lam) * w + lam * z

    Rlt = (2 - lam) / lam * (p + 1) * w @ w.T

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for chi  in Case II\n " % (run_time / nSimu))