import numpy as np
from related_functions import estimate_sq, build_omega,build_R
import time
from IRLS import IRLS
from scipy.stats import t


p = 2
Num = 1000

nSimu = 10000

file_name = 'QR_LS_time'
n=20
lam = 0.1
##  Case I


#normal

# 真实模型参数
eta_t = np.array([3,2]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数
np.random.seed(2)
x = np.random.normal(loc=0,scale=0.5,size=Num)
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 1
err = np.random.normal(0, var_t, (Num, 1)) #normal errors

y_0 = X_0 @ eta_t + err


# IC 状态参数估计
tau = 0.5
rho = 0.25


# 估计三个分位点的回归系数
beta_tau_0 = IRLS(tau, y_0, X_0)
beta_rho_0 = IRLS(rho, y_0, X_0)
beta_1rho_0 = IRLS(1 - rho,y_0, X_0)

# 估计设计矩阵

D_hat = X_0.T @ X_0 / Num
print(D_hat)

# 估计稀疏函数 s(q)
s_tau = estimate_sq(X_0,y_0, tau)
s_rho = estimate_sq(X_0,y_0, rho)
s_1rho = estimate_sq(X_0,y_0, 1 - rho)
print(s_tau,s_rho,s_1rho)

be_all_0 = np.concatenate([beta_tau_0, beta_rho_0, beta_1rho_0])
print(be_all_0.shape)

# 构建协方差矩阵
Omega = build_omega([tau, rho, 1 - rho], [s_tau, s_rho, s_1rho])

R = build_R(p)
Sigma = R @ np.kron(Omega, np.linalg.inv(D_hat)) @ R.T

S_inv = np.linalg.inv(Sigma)

z = np.zeros((2 * p, 1))
start_time = time.time()
for _ in range(nSimu):


    x = np.random.normal(loc=0, scale=0.5, size=n)
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = np.random.normal(0, var_t, (n, 1))
    y = X @ eta_t + err

    beta_tau = IRLS(tau, y, X)
    beta_rho = IRLS(rho, y, X)
    beta_1rho = IRLS(1 - rho, y, X)
    det = np.concatenate([beta_tau, beta_rho, beta_1rho]) - be_all_0
    v = R @ det
    z = (1 - lam) * z + lam * v

    Rlt = n * np.squeeze(z) @ S_inv @ np.squeeze(z)

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for normal  in Case I\n " % (run_time / nSimu))

# t

# 真实模型参数
eta_t = np.array([3, 2]).reshape(-1, 1)  # regression coefficient
var_t = 1  # error variance

# 训练数据,用于估计 Phase I 参数
np.random.seed(2)
x = np.random.normal(loc=0, scale=0.5, size=Num)
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 2 -- t-distribution
err = t.rvs(df=4,size=Num,random_state=9).reshape(-1,1)/np.sqrt(2) #t-distribution
print(np.mean(err))
print(np.std(err))


y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau = 0.5
rho = 0.25

# 估计三个分位点的回归系数
beta_tau_0 = IRLS(tau, y_0, X_0)
beta_rho_0 = IRLS(rho, y_0, X_0)
beta_1rho_0 = IRLS(1 - rho, y_0, X_0)

# 估计设计矩阵

D_hat = X_0.T @ X_0 / Num
print(D_hat)

# 估计稀疏函数 s(q)
s_tau = estimate_sq(X_0, y_0, tau)
s_rho = estimate_sq(X_0, y_0, rho)
s_1rho = estimate_sq(X_0, y_0, 1 - rho)
print(s_tau, s_rho, s_1rho)

be_all_0 = np.concatenate([beta_tau_0, beta_rho_0, beta_1rho_0])
print(be_all_0.shape)

# 构建协方差矩阵
Omega = build_omega([tau, rho, 1 - rho], [s_tau, s_rho, s_1rho])

R = build_R(p)
Sigma = R @ np.kron(Omega, np.linalg.inv(D_hat)) @ R.T

S_inv = np.linalg.inv(Sigma)

z = np.zeros((2 * p, 1))
start_time = time.time()
for _ in range(nSimu):
    x = np.random.normal(loc=0, scale=0.5, size=n)
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = t.rvs(df=4, size=n).reshape(-1, 1) / np.sqrt(2)
    y = X @ eta_t + err

    beta_tau = IRLS(tau, y, X)
    beta_rho = IRLS(rho, y, X)
    beta_1rho = IRLS(1 - rho, y, X)
    det = np.concatenate([beta_tau, beta_rho, beta_1rho]) - be_all_0
    v = R @ det
    z = (1 - lam) * z + lam * v

    Rlt = n * np.squeeze(z) @ S_inv @ np.squeeze(z)

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for t  in Case I\n " % (run_time / nSimu))



# chi

# 真实模型参数
eta_t = np.array([3, 2]).reshape(-1, 1)  # regression coefficient
var_t = 1  # error variance

# 训练数据,用于估计 Phase I 参数
np.random.seed(2)
x = np.random.normal(loc=0, scale=0.5, size=Num)
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
#Sceniro 3 chi
err = (np.random.chisquare(4, Num).reshape(-1,1) - 4)/(2*np.sqrt(2))
print(np.mean(err))
print(np.std(err))


y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau = 0.5
rho = 0.25

# 估计三个分位点的回归系数
beta_tau_0 = IRLS(tau, y_0, X_0)
beta_rho_0 = IRLS(rho, y_0, X_0)
beta_1rho_0 = IRLS(1 - rho, y_0, X_0)

# 估计设计矩阵

D_hat = X_0.T @ X_0 / Num
print(D_hat)

# 估计稀疏函数 s(q)
s_tau = estimate_sq(X_0, y_0, tau)
s_rho = estimate_sq(X_0, y_0, rho)
s_1rho = estimate_sq(X_0, y_0, 1 - rho)
print(s_tau, s_rho, s_1rho)

be_all_0 = np.concatenate([beta_tau_0, beta_rho_0, beta_1rho_0])
print(be_all_0.shape)

# 构建协方差矩阵
Omega = build_omega([tau, rho, 1 - rho], [s_tau, s_rho, s_1rho])

R = build_R(p)
Sigma = R @ np.kron(Omega, np.linalg.inv(D_hat)) @ R.T

S_inv = np.linalg.inv(Sigma)

z = np.zeros((2 * p, 1))
start_time = time.time()
for _ in range(nSimu):
    x = np.random.normal(loc=0, scale=0.5, size=n)
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = (np.random.chisquare(4, n).reshape(-1, 1) - 4) / (2 * np.sqrt(2))
    y = X @ eta_t + err

    beta_tau = IRLS(tau, y, X)
    beta_rho = IRLS(rho, y, X)
    beta_1rho = IRLS(1 - rho, y, X)
    det = np.concatenate([beta_tau, beta_rho, beta_1rho]) - be_all_0
    v = R @ det
    z = (1 - lam) * z + lam * v

    Rlt = n * np.squeeze(z) @ S_inv @ np.squeeze(z)

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for chi  in Case I\n " % (run_time / nSimu))

##  Case II

p=5
# normal

# 真实模型参数
eta_t = np.array([2,1,-3,-2,4]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数 Multiple
np.random.seed(2)
mean_x = np.zeros(p-1)
cov_x = np.array([[0.5,0.25,0.125,0.0625],[0.25,0.5,0.25,0.125],[0.125,0.25,0.5,0.25],[0.0625,0.125,0.25,0.5]])
print(cov_x)
x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=Num).T
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
# Sceniro 1
err = np.random.normal(0, var_t, (Num, 1))  # normal errors

y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau = 0.5
rho = 0.25

# 估计三个分位点的回归系数
beta_tau_0 = IRLS(tau, y_0, X_0)
beta_rho_0 = IRLS(rho, y_0, X_0)
beta_1rho_0 = IRLS(1 - rho, y_0, X_0)

# 估计设计矩阵

D_hat = X_0.T @ X_0 / Num
print(D_hat)

# 估计稀疏函数 s(q)
s_tau = estimate_sq(X_0, y_0, tau)
s_rho = estimate_sq(X_0, y_0, rho)
s_1rho = estimate_sq(X_0, y_0, 1 - rho)
print(s_tau, s_rho, s_1rho)

be_all_0 = np.concatenate([beta_tau_0, beta_rho_0, beta_1rho_0])
print(be_all_0.shape)

# 构建协方差矩阵
Omega = build_omega([tau, rho, 1 - rho], [s_tau, s_rho, s_1rho])

R = build_R(p)
Sigma = R @ np.kron(Omega, np.linalg.inv(D_hat)) @ R.T

S_inv = np.linalg.inv(Sigma)

z = np.zeros((2 * p, 1))
start_time = time.time()
for _ in range(nSimu):
    x = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=n).T
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = np.random.normal(0, var_t, (n, 1))
    y = X @ eta_t + err

    beta_tau = IRLS(tau, y, X)
    beta_rho = IRLS(rho, y, X)
    beta_1rho = IRLS(1 - rho, y, X)
    det = np.concatenate([beta_tau, beta_rho, beta_1rho]) - be_all_0
    v = R @ det
    z = (1 - lam) * z + lam * v

    Rlt = n * np.squeeze(z) @ S_inv @ np.squeeze(z)

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for normal  in Case II\n " % (run_time / nSimu))

# t

# 真实模型参数
eta_t = np.array([2,1,-3,-2,4]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数 Multiple
np.random.seed(2)
mean_x = np.zeros(p-1)
cov_x = np.array([[0.5,0.25,0.125,0.0625],[0.25,0.5,0.25,0.125],[0.125,0.25,0.5,0.25],[0.0625,0.125,0.25,0.5]])
print(cov_x)
x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=Num).T
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
# Sceniro 2 -- t-distribution
err = t.rvs(df=4, size=Num, random_state=9).reshape(-1, 1) / np.sqrt(2)  # t-distribution
print(np.mean(err))
print(np.std(err))

y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau = 0.5
rho = 0.25

# 估计三个分位点的回归系数
beta_tau_0 = IRLS(tau, y_0, X_0)
beta_rho_0 = IRLS(rho, y_0, X_0)
beta_1rho_0 = IRLS(1 - rho, y_0, X_0)

# 估计设计矩阵

D_hat = X_0.T @ X_0 / Num
print(D_hat)

# 估计稀疏函数 s(q)
s_tau = estimate_sq(X_0, y_0, tau)
s_rho = estimate_sq(X_0, y_0, rho)
s_1rho = estimate_sq(X_0, y_0, 1 - rho)
print(s_tau, s_rho, s_1rho)

be_all_0 = np.concatenate([beta_tau_0, beta_rho_0, beta_1rho_0])
print(be_all_0.shape)

# 构建协方差矩阵
Omega = build_omega([tau, rho, 1 - rho], [s_tau, s_rho, s_1rho])

R = build_R(p)
Sigma = R @ np.kron(Omega, np.linalg.inv(D_hat)) @ R.T

S_inv = np.linalg.inv(Sigma)

z = np.zeros((2 * p, 1))
start_time = time.time()
for _ in range(nSimu):
    x = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=n).T
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = t.rvs(df=4, size=n).reshape(-1, 1) / np.sqrt(2)
    y = X @ eta_t + err

    beta_tau = IRLS(tau, y, X)
    beta_rho = IRLS(rho, y, X)
    beta_1rho = IRLS(1 - rho, y, X)
    det = np.concatenate([beta_tau, beta_rho, beta_1rho]) - be_all_0
    v = R @ det
    z = (1 - lam) * z + lam * v

    Rlt = n * np.squeeze(z) @ S_inv @ np.squeeze(z)

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for t  in Case II\n " % (run_time / nSimu))

# chi

# 真实模型参数
eta_t = np.array([2,1,-3,-2,4]).reshape(-1,1) # regression coefficient
var_t = 1 # error variance

#训练数据,用于估计 Phase I 参数 Multiple
np.random.seed(2)
mean_x = np.zeros(p-1)
cov_x = np.array([[0.5,0.25,0.125,0.0625],[0.25,0.5,0.25,0.125],[0.125,0.25,0.5,0.25],[0.0625,0.125,0.25,0.5]])
print(cov_x)
x = np.random.multivariate_normal(mean=mean_x,cov=cov_x,size=Num).T
l_1 = np.array([1 for i in range(Num)])
X_0 = np.vstack((l_1, x)).T

# 随机误差
# Sceniro 3 chi
err = (np.random.chisquare(4, Num).reshape(-1, 1) - 4) / (2 * np.sqrt(2))
print(np.mean(err))
print(np.std(err))

y_0 = X_0 @ eta_t + err

# IC 状态参数估计
tau = 0.5
rho = 0.25

# 估计三个分位点的回归系数
beta_tau_0 = IRLS(tau, y_0, X_0)
beta_rho_0 = IRLS(rho, y_0, X_0)
beta_1rho_0 = IRLS(1 - rho, y_0, X_0)

# 估计设计矩阵

D_hat = X_0.T @ X_0 / Num
print(D_hat)

# 估计稀疏函数 s(q)
s_tau = estimate_sq(X_0, y_0, tau)
s_rho = estimate_sq(X_0, y_0, rho)
s_1rho = estimate_sq(X_0, y_0, 1 - rho)
print(s_tau, s_rho, s_1rho)

be_all_0 = np.concatenate([beta_tau_0, beta_rho_0, beta_1rho_0])
print(be_all_0.shape)

# 构建协方差矩阵
Omega = build_omega([tau, rho, 1 - rho], [s_tau, s_rho, s_1rho])

R = build_R(p)
Sigma = R @ np.kron(Omega, np.linalg.inv(D_hat)) @ R.T

S_inv = np.linalg.inv(Sigma)

z = np.zeros((2 * p, 1))
start_time = time.time()
for _ in range(nSimu):
    x = np.random.multivariate_normal(mean=mean_x, cov=cov_x, size=n).T
    l_1 = np.array([1 for i in range(n)])
    X = np.vstack((l_1, x)).T
    err = (np.random.chisquare(4, n).reshape(-1, 1) - 4) / (2 * np.sqrt(2))
    y = X @ eta_t + err

    beta_tau = IRLS(tau, y, X)
    beta_rho = IRLS(rho, y, X)
    beta_1rho = IRLS(1 - rho, y, X)
    det = np.concatenate([beta_tau, beta_rho, beta_1rho]) - be_all_0
    v = R @ det
    z = (1 - lam) * z + lam * v

    Rlt = n * np.squeeze(z) @ S_inv @ np.squeeze(z)

end_time = time.time()
run_time = end_time - start_time

with open(file_name + '.txt', 'a') as file:
    file.write("it  cost %s s for chi  in Case II\n " % (run_time / nSimu))