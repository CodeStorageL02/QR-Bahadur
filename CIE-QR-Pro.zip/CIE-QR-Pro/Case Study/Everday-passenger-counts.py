import numpy as np
import pandas as pd
import datetime as dt
import matplotlib.pyplot as plt

DF1 = pd.read_excel('Phase_I.xlsx')
DF2 = pd.read_excel('Phase_II.xlsx')

Total = pd.concat([DF1,DF2],axis=0)

print(Total.shape)

time = np.arange(78)

## Everyday passenger counts in y

Y_T = Total['y'].to_numpy()
Matrix = np.zeros((238,78))

plt.figure(figsize=(12, 5))
for i in range(238):
    Matrix[i] = Y_T[i*78:(i+1)*78]
    plt.plot(time, Matrix[i], color='blue', alpha=0.5, linewidth=0.8)

plt.plot(time, np.mean(Matrix,axis=0), color='red', linestyle='--', linewidth=1.5, label='Mean')

plt.xlabel('Time points', fontsize=12)
plt.ylabel('Passenger counts', fontsize=12)
plt.legend(loc='upper right', fontsize=12)
plt.grid(False)
plt.ylim(bottom=0)  # 保证y轴从0开始
plt.tight_layout()
plt.show()


# Everyday passenger counts in x1
X1_T = Total['x1'].to_numpy()
Matrix = np.zeros((238,78))

plt.figure(figsize=(12, 5))
for i in range(238):
    Matrix[i] = X1_T[i*78:(i+1)*78]
    plt.plot(time, Matrix[i], color='blue', alpha=0.5, linewidth=0.8)

plt.plot(time, np.mean(Matrix,axis=0), color='red', linestyle='--', linewidth=1.5, label='Mean')

plt.xlabel('Time points', fontsize=12)
plt.ylabel('Passenger counts', fontsize=12)
plt.legend(loc='upper right', fontsize=12)
plt.grid(False)
plt.ylim(bottom=0)  # 保证y轴从0开始
plt.tight_layout()

plt.show()

# Everyday passenger counts in x2
X2_T = Total['x2'].to_numpy()
Matrix = np.zeros((238,78))

plt.figure(figsize=(12, 5))
for i in range(238):
    Matrix[i] = X2_T[i*78:(i+1)*78]
    plt.plot(time, Matrix[i], color='blue', alpha=0.5, linewidth=0.8)

plt.plot(time, np.mean(Matrix,axis=0), color='red', linestyle='--', linewidth=1.5, label='Mean')

plt.xlabel('Time points', fontsize=12)
plt.ylabel('Passenger counts', fontsize=12)
plt.legend(loc='upper right', fontsize=12)
plt.grid(False)
plt.ylim(bottom=0)  # 保证y轴从0开始
plt.tight_layout()

plt.show()


# Everyday passenger counts in x3
X3_T = Total['x3'].to_numpy()
Matrix = np.zeros((238,78))

plt.figure(figsize=(12, 5))
for i in range(238):
    Matrix[i] = X3_T[i*78:(i+1)*78]
    plt.plot(time, Matrix[i], color='blue', alpha=0.5, linewidth=0.8)

plt.plot(time, np.mean(Matrix,axis=0), color='red', linestyle='--', linewidth=1.5, label='Mean')

plt.xlabel('Time points', fontsize=12)
plt.ylabel('Passenger counts', fontsize=12)
plt.legend(loc='upper right', fontsize=12)
plt.grid(False)
plt.ylim(bottom=0)  # 保证y轴从0开始
plt.tight_layout()

plt.show()



# Everyday passenger counts in x4
X4_T = Total['x4'].to_numpy()
Matrix = np.zeros((238,78))

plt.figure(figsize=(12, 5))
for i in range(238):
    Matrix[i] = X4_T[i*78:(i+1)*78]
    plt.plot(time, Matrix[i], color='blue', alpha=0.5, linewidth=0.8)

plt.plot(time, np.mean(Matrix,axis=0), color='red', linestyle='--', linewidth=1.5, label='Mean')

plt.xlabel('Time points', fontsize=12)
plt.ylabel('Passenger counts', fontsize=12)
plt.legend(loc='upper right', fontsize=12)
plt.grid(False)
plt.ylim(bottom=0)  # 保证y轴从0开始
plt.tight_layout()

plt.show()